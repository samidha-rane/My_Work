package com.example.competitiveexampreparationapp

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper


class DBHelper(context: Context) : SQLiteOpenHelper(context, "progress.db", null, 1) {

    companion object {
        private const val TABLE_SUBJECTS = "subjects"
        private const val TABLE_TESTS = "test_attempts"
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE $TABLE_SUBJECTS(" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "userId TEXT," +
                    "name TEXT," +
                    "score INTEGER," +
                    "total INTEGER)"
        )

        db.execSQL(
            "CREATE TABLE $TABLE_TESTS(" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "userId TEXT," +
                    "date INTEGER," +  // store as LONG
                    "subject TEXT," +
                    "score INTEGER," +
                    "total INTEGER," +
                    "improved INTEGER)"
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_SUBJECTS")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_TESTS")
        onCreate(db)
    }

    fun insertOrUpdateSubject(userId: String, name: String, score: Int, total: Int) {
        val db = writableDatabase
        val cursor = db.query(
            TABLE_SUBJECTS,
            null,
            "userId=? AND name=?",
            arrayOf(userId, name),
            null, null, null
        )

        if (cursor.moveToFirst()) {
            val values = ContentValues().apply {
                put("score", score)
                put("total", total)
            }
            db.update(TABLE_SUBJECTS, values, "userId=? AND name=?", arrayOf(userId, name))
        } else {
            val values = ContentValues().apply {
                put("userId", userId)
                put("name", name)
                put("score", score)
                put("total", total)
            }
            db.insert(TABLE_SUBJECTS, null, values)
        }
        cursor.close()
    }

    fun getSubjectsForUser(userId: String): List<SubjectProgress> {
        val list = mutableListOf<SubjectProgress>()
        val db = readableDatabase
        val cursor = db.query(TABLE_SUBJECTS, null, "userId=?", arrayOf(userId), null, null, null)
        cursor.use {
            while (it.moveToNext()) {
                val name = it.getString(it.getColumnIndexOrThrow("name"))
                val score = it.getInt(it.getColumnIndexOrThrow("score"))
                val total = it.getInt(it.getColumnIndexOrThrow("total"))
                val progress = if (total > 0) (score * 100) / total else 0
                list.add(SubjectProgress(name, "$score/$total", progress))
            }
        }
        return list
    }

    fun insertTest(userId: String, date: Long, subject: String, score: Int, total: Int, improved: Boolean?) {
        val db = writableDatabase
        val values = ContentValues().apply {
            put("userId", userId)
            put("date", date) // store as Long
            put("subject", subject)
            put("score", score)
            put("total", total)
            put("improved", when(improved) { true -> 1; false -> 0; else -> -1 })
        }
        db.insert(TABLE_TESTS, null, values)
    }


    fun getTestsForUser(userId: String): List<TestAttempt> {
        val list = mutableListOf<TestAttempt>()
        val db = readableDatabase
        val cursor = db.query(TABLE_TESTS, null, "userId=?", arrayOf(userId), null, null, "date DESC")
        cursor.use {
            while (it.moveToNext()) {
                val date = it.getLong(it.getColumnIndexOrThrow("date"))
                val subject = it.getString(it.getColumnIndexOrThrow("subject"))
                val score = it.getInt(it.getColumnIndexOrThrow("score"))
                val total = it.getInt(it.getColumnIndexOrThrow("total"))
                val improvedInt = it.getInt(it.getColumnIndexOrThrow("improved"))
                val improved = when (improvedInt) {
                    1 -> true
                    0 -> false
                    else -> null
                }
                val percentage = if (total > 0) (score * 100) / total else 0
                list.add(TestAttempt(date.toString(), subject, percentage, improved))
            }
        }
        return list
    }
}
