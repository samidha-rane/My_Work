package com.example.competitiveexampreparationapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth

class HomePageActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var dbHelper: UserDBHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home_page)

        auth = FirebaseAuth.getInstance()
        dbHelper = UserDBHelper(this)

        // ✅ Check if Firebase user exists
        val firebaseUser = auth.currentUser
        if (firebaseUser == null) {
            navigateToLogin()
            return
        }

        // ✅ Fetch last saved user from SQLite
        val localUsername = dbHelper.getLastUsername()

        // Show user’s name → prefer SQLite username, fallback to Firebase email
        val displayName = localUsername ?: firebaseUser.displayName ?: firebaseUser.email
        findViewById<TextView>(R.id.tvWelcome).text = "Welcome, $displayName"

        // Navigation buttons
        findViewById<Button>(R.id.btnSubjectTest).setOnClickListener { navigateTo(SubjectSelectionActivity::class.java) }
        findViewById<Button>(R.id.btnProgress).setOnClickListener { navigateTo(ProgressActivity::class.java) }
        findViewById<Button>(R.id.btnProfile).setOnClickListener { navigateTo(ProfileActivity::class.java) }
        findViewById<Button>(R.id.btnMyScores).setOnClickListener { navigateTo(ScoresActivity::class.java) }

        // ✅ Logout → clears Firebase and sends back to login
        findViewById<Button>(R.id.btnLogout).setOnClickListener {
            auth.signOut()
            navigateToLogin()
        }
    }

    override fun onStart() {
        super.onStart()
        if (auth.currentUser == null) {
            navigateToLogin()
        }
    }

    private fun navigateToLogin() {
        startActivity(Intent(this, LoginActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
        })
        finish()
    }

    private fun navigateTo(activity: Class<*>) {
        startActivity(Intent(this, activity))
    }
}
