package com.example.competitiveexampreparationapp

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.competitiveexampreparationapp.R

class SubjectsFragment : Fragment() {

    private lateinit var rvSubjects: RecyclerView
    private lateinit var subjectAdapter: SubjectsAdapter
    private lateinit var dbHelper: DBHelper
    private lateinit var userId: String

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val view = inflater.inflate(R.layout.fragment_subjects, container, false)
        rvSubjects = view.findViewById(R.id.rvSubjects)
        rvSubjects.layoutManager = LinearLayoutManager(requireContext())

        dbHelper = DBHelper(requireContext())

        val prefs = requireContext().getSharedPreferences("UserPrefs", Context.MODE_PRIVATE)
        userId = prefs.getString("username", "") ?: ""

        // Initial empty adapter
        subjectAdapter = SubjectsAdapter(emptyList())
        rvSubjects.adapter = subjectAdapter

        return view
    }

    override fun onResume() {
        super.onResume()
        refreshSubjects()
    }

    private fun refreshSubjects() {
        val subjects = dbHelper.getSubjectsForUser(userId)
        subjectAdapter.updateData(subjects)
    }
}
