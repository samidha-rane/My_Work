package com.example.competitiveexampreparationapp

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.competitiveexampreparationapp.R
import com.google.android.material.snackbar.Snackbar

class RegistrationActivity : AppCompatActivity() {

    private lateinit var etFirstName: EditText
    private lateinit var etLastName: EditText
    private lateinit var btnRegister: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registration)

        etFirstName = findViewById(R.id.etFirstName)
        etLastName = findViewById(R.id.etLastName)
        btnRegister = findViewById(R.id.btnRegister)

        btnRegister.setOnClickListener {
            val firstName = etFirstName.text.toString().trim()
            val lastName = etLastName.text.toString().trim()

            if (firstName.isNotEmpty() && lastName.isNotEmpty()) {
                val username = generateUsername(firstName)
                val password = generatePassword(lastName)

                // Store credentials in SharedPreferences
                val sharedPref = getSharedPreferences("UserPrefs", MODE_PRIVATE)
                val editor = sharedPref.edit()
                editor.putString("username", username)
                editor.putString("password", password)
                editor.apply()

                // Show credentials in a Snackbar with "COPY" option
                val message = "Username: $username | Password: $password"
                Snackbar.make(btnRegister, message, Snackbar.LENGTH_LONG)
                    .setAction("COPY") {
                        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        val clip = ClipData.newPlainText("credentials", message)
                        clipboard.setPrimaryClip(clip)
                        Toast.makeText(this, "Copied to Clipboard!", Toast.LENGTH_SHORT).show()
                    }
                    .show()

                // Move to LoginActivity after showing Snackbar
                btnRegister.postDelayed({
                    val intent = Intent(this, LoginActivity::class.java)
                    startActivity(intent)
                    finish()
                }, 5500) // waits until snackbar disappears

            } else {
                Toast.makeText(this, "Please enter both first and last name", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun generateUsername(firstName: String): String {
        return firstName.take(4) + (1000..9999).random()
    }

    private fun generatePassword(lastName: String): String {
        return lastName.take(4) + (10000..99999).random()
    }
}
