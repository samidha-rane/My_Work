package com.example.competitiveexampreparationapp

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.competitiveexampreparationapp.R
import com.google.android.material.progressindicator.LinearProgressIndicator

class SubjectsAdapter(
    private var subjects: List<SubjectProgress>  // 🔄 Made mutable with a setter method
) : RecyclerView.Adapter<SubjectsAdapter.SubjectViewHolder>() {

    class SubjectViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvSubjectName: TextView = itemView.findViewById(R.id.tvSubjectName)
        val tvScore: TextView = itemView.findViewById(R.id.tvScore)
        val progressBar: LinearProgressIndicator = itemView.findViewById(R.id.progressBar)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SubjectViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_subject, parent, false)
        return SubjectViewHolder(view)
    }

    override fun onBindViewHolder(holder: SubjectViewHolder, position: Int) {
        val subject = subjects[position]
        holder.tvSubjectName.text = subject.name
        holder.tvScore.text = subject.scoreText
        holder.progressBar.progress = subject.progress
    }

    override fun getItemCount(): Int = subjects.size

    // ✅ Add this method to update the list
    fun updateData(newSubjects: List<SubjectProgress>) {
        subjects = newSubjects
        notifyDataSetChanged()
    }
}
