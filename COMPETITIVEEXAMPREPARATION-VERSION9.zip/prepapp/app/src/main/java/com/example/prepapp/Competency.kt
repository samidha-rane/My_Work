package com.example.competitiveexampreparationapp

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.competitiveexampreparationapp.R

class Competency : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_competency)

        val dbHelper = ReportDBHelper(this)

        // ✅ Get latest userId dynamically from DB
        val userId = dbHelper.getLatestUserId()

        val quantText: TextView = findViewById(R.id.competencyQuant)
        val reasoningText: TextView = findViewById(R.id.competencyReasoning)
        val englishText: TextView = findViewById(R.id.competencyEnglish)

        if (userId == null) {
            // No attempts found → show message
            quantText.text = "No data found"
            reasoningText.text = "No data found"
            englishText.text = "No data found"
            return
        }

        val subjects = listOf("Quantitative Aptitude", "Reasoning", "English")

        for (subject in subjects) {
            val attempts = dbHelper.getAttemptsForUser(userId, subject)
            val totalCorrect = attempts.count { it.userAnswer == it.correctIndex }
            val totalQuestions = attempts.size
            val percentage = if (totalQuestions > 0) (totalCorrect * 100) / totalQuestions else 0

            when (subject) {
                "Quantitative Aptitude" -> quantText.text = "Quantitative Aptitude: $percentage%"
                "Reasoning" -> reasoningText.text = "Reasoning: $percentage%"
                "English" -> englishText.text = "English: $percentage%"
            }
        }
    }
}
