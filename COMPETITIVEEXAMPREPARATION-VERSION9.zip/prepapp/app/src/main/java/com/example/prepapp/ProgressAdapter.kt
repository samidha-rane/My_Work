package com.example.competitiveexampreparationapp

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ProgressBar
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.*

class ProgressAdapter(
    private val context: Context,
    private val data: List<ExamResult>
) : BaseAdapter() {

    override fun getCount(): Int = data.size

    override fun getItem(position: Int): Any = data[position]

    override fun getItemId(position: Int): Long = position.toLong()

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val view = convertView ?: LayoutInflater.from(context)
            .inflate(R.layout.item_progress, parent, false)

        val tvProgressInfo = view.findViewById<TextView>(R.id.tvProgressInfo)
        val progressBar = view.findViewById<ProgressBar>(R.id.progressBarScore)

        val item = data[position]

        // Format date
        val sdf = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
        val dateStr = sdf.format(Date(item.date))

        // Set progress info
        tvProgressInfo.text = "$dateStr | ${item.subject} | ${item.score}/${item.total}"

        // Calculate percentage
        val percentage = if (item.total > 0) (item.score * 100) / item.total else 0
        progressBar.progress = percentage

        // Set dynamic color
        val color = when {
            percentage >= 80 -> 0xFF4CAF50.toInt() // Green
            percentage >= 50 -> 0xFFFFC107.toInt() // Amber
            else -> 0xFFF44336.toInt()            // Red
        }
        progressBar.progressTintList = android.content.res.ColorStateList.valueOf(color)

        return view
    }
}
