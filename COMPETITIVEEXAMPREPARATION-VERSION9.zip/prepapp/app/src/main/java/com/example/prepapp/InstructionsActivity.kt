package com.example.competitiveexampreparationapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.competitiveexampreparationapp.R

class InstructionsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_instructions)

        val subject = intent.getStringExtra("subject") ?: "Subject"
        findViewById<TextView>(R.id.tvTitle).text = "$subject - Sample Test"

        // Instructions are already loaded from strings.xml
        // No need to set text programmatically unless you want dynamic changes

        findViewById<Button>(R.id.btnStart).setOnClickListener {
            val i = Intent(this, TestActivity::class.java)
            i.putExtra("subject", subject)
            startActivity(i)
        }
    }
}
