package com.example.competitiveexampreparationapp

data class Question(
    val id: Int,
    val subject: String,
    val text: String,
    val options: List<String>,
    val correctIndex: Int
)