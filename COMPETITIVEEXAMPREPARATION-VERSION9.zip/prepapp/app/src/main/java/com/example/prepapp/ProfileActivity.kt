package com.example.competitiveexampreparationapp

import android.database.Cursor
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.competitiveexampreparationapp.R

class ProfileActivity : AppCompatActivity() {

    private lateinit var tvName: TextView
    private lateinit var tvUsername: TextView
    private lateinit var tvUserId: TextView
    private lateinit var tvQuantitative: TextView
    private lateinit var tvReasoning: TextView
    private lateinit var tvEnglish: TextView
    private lateinit var tvOverallPercentage: TextView

    // New summary textviews
    private lateinit var tvQuantitativeSummary: TextView
    private lateinit var tvReasoningSummary: TextView
    private lateinit var tvEnglishSummary: TextView

    private lateinit var etNewPassword: EditText
    private lateinit var btnChangePassword: Button

    private lateinit var userDbHelper: UserDBHelper
    private lateinit var examDbHelper: ExamDBHelper
    private lateinit var profileDbHelper: ProfileDBHelper
    private var currentUsername: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        // Init views
        tvName = findViewById(R.id.tvName)
        tvUsername = findViewById(R.id.tvUsername)
        tvUserId = findViewById(R.id.tvUserId)
        tvQuantitative = findViewById(R.id.tvQuantitative)
        tvReasoning = findViewById(R.id.tvReasoning)
        tvEnglish = findViewById(R.id.tvEnglish)
        tvOverallPercentage = findViewById(R.id.tvOverallPercentage)

        tvQuantitativeSummary = findViewById(R.id.tvQuantitativeSummary)
        tvReasoningSummary = findViewById(R.id.tvReasoningSummary)
        tvEnglishSummary = findViewById(R.id.tvEnglishSummary)

        etNewPassword = findViewById(R.id.etNewPassword)
        btnChangePassword = findViewById(R.id.btnChangePassword)

        userDbHelper = UserDBHelper(this)
        examDbHelper = ExamDBHelper(this)
        profileDbHelper = ProfileDBHelper(this)

        // Get logged-in username
        currentUsername = intent.getStringExtra("username")
            ?: userDbHelper.getLastUsername()

        if (currentUsername != null) {
            loadProfile(currentUsername!!)
        }

        btnChangePassword.setOnClickListener {
            val newPass = etNewPassword.text.toString().trim()
            if (newPass.isNotEmpty() && currentUsername != null) {
                val success = userDbHelper.updatePassword(currentUsername!!, newPass)
                if (success) {
                    Toast.makeText(this, "Password updated", Toast.LENGTH_SHORT).show()
                    etNewPassword.text.clear()
                } else {
                    Toast.makeText(this, "Failed to update password", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun loadProfile(username: String) {
        // Fetch user info
        val udb = userDbHelper.readableDatabase
        udb.rawQuery(
            "SELECT id, firstname, lastname FROM users WHERE username=?",
            arrayOf(username)
        ).use { cursor ->
            if (cursor.moveToFirst()) {
                val id = cursor.getInt(0)
                val firstName = cursor.getString(1)
                val lastName = cursor.getString(2)
                tvUserId.text = "ID: $id"
                tvName.text = "$firstName $lastName"
                tvUsername.text = username
            }
        }
        udb.close()

        // Detect if 'topic' column exists in results table
        val edb = examDbHelper.readableDatabase
        var hasTopicColumn = false
        edb.rawQuery("PRAGMA table_info(${ExamDBHelper.TABLE_RESULTS})", null).use { c ->
            while (c.moveToNext()) {
                val colName = c.getString(c.getColumnIndexOrThrow("name"))
                if (colName.equals("topic", ignoreCase = true)) {
                    hasTopicColumn = true
                    break
                }
            }
        }

        if (hasTopicColumn) {
            // Aggregate by subject and topic
            // Query: subject, score, total, topic
            val subjectTotals = mutableMapOf<String, IntArray>() // subject -> [scoreSum, totalSum]
            val subjectTopicTotals = mutableMapOf<String, MutableMap<String, IntArray>>() // subject -> (topic -> [scoreSum, totalSum])

            edb.rawQuery(
                "SELECT subject, score, total, topic FROM ${ExamDBHelper.TABLE_RESULTS} WHERE username=?",
                arrayOf(username)
            ).use { cursor ->
                while (cursor.moveToNext()) {
                    val subj = cursor.getString(0) ?: ""
                    val score = cursor.getInt(1)
                    val total = cursor.getInt(2)
                    val topic = cursor.getString(3) ?: "Unknown"

                    val subjArr = subjectTotals.getOrPut(subj) { IntArray(2) } // [scoreSum, totalSum]
                    subjArr[0] = subjArr[0] + score
                    subjArr[1] = subjArr[1] + total

                    val topicMap = subjectTopicTotals.getOrPut(subj) { mutableMapOf() }
                    val topicArr = topicMap.getOrPut(topic) { IntArray(2) }
                    topicArr[0] = topicArr[0] + score
                    topicArr[1] = topicArr[1] + total
                }
            }

            // Compute percents and best/worst topics per subject
            fun percent(scoreSum: Int, totalSum: Int) = if (totalSum > 0) (scoreSum * 100) / totalSum else 0

            val quantPercent = percent(subjectTotals["Quantitative Aptitude"]?.get(0) ?: 0, subjectTotals["Quantitative Aptitude"]?.get(1) ?: 0)
            val reasoningPercent = percent(subjectTotals["Reasoning"]?.get(0) ?: 0, subjectTotals["Reasoning"]?.get(1) ?: 0)
            val englishPercent = percent(subjectTotals["English"]?.get(0) ?: 0, subjectTotals["English"]?.get(1) ?: 0)

            tvQuantitative.text = "Quantitative Aptitude: $quantPercent%"
            tvReasoning.text = "Reasoning: $reasoningPercent%"
            tvEnglish.text = "English: $englishPercent%"

            // overall
            val totalScore = subjectTotals.values.sumOf { it[0] }
            val totalMarks = subjectTotals.values.sumOf { it[1] }
            val overallPercent = if (totalMarks > 0) (totalScore * 100) / totalMarks else 0
            tvOverallPercentage.text = "Overall: $overallPercent%"

            // compute best/worst topic strings
            fun getBestWorstFor(subject: String): Pair<String, String> {
                val tmap = subjectTopicTotals[subject] ?: return Pair("N/A", "N/A")
                var bestTopic = "N/A"; var worstTopic = "N/A"
                var bestPct = Int.MIN_VALUE; var worstPct = Int.MAX_VALUE
                for ((t, arr) in tmap) {
                    val pct = percent(arr[0], arr[1])
                    if (pct > bestPct) { bestPct = pct; bestTopic = t }
                    if (pct < worstPct) { worstPct = pct; worstTopic = t }
                }
                return Pair(bestTopic, worstTopic)
            }

            val (bestQ, worstQ) = getBestWorstFor("Quantitative Aptitude")
            val (bestR, worstR) = getBestWorstFor("Reasoning")
            val (bestE, worstE) = getBestWorstFor("English")

            tvQuantitativeSummary.text = "Strength: $bestQ, Weakness: $worstQ"
            tvReasoningSummary.text = "Strength: $bestR, Weakness: $worstR"
            tvEnglishSummary.text = "Strength: $bestE, Weakness: $worstE"

            // Save overall into profile DB (optional)
            profileDbHelper.insertOrUpdateProfile(username, "N/A", overallPercent.toDouble())

        } else {
            // topic column not present -> fall back to subject-level only (use existing helper)
            val results = examDbHelper.getAllResults(username)

            if (results.isNotEmpty()) {
                var totalScore = 0
                var totalMarks = 0
                val subjScores = mutableMapOf<String, IntArray>() // subject -> [scoreSum, totalSum]

                for (r in results) {
                    val arr = subjScores.getOrPut(r.subject) { IntArray(2) }
                    arr[0] += r.score
                    arr[1] += r.total
                    totalScore += r.score
                    totalMarks += r.total
                }

                fun pctFor(s: String) = if (subjScores[s]?.get(1) ?: 0 > 0)
                    (subjScores[s]!![0] * 100) / subjScores[s]!![1] else 0

                val quantPercent = pctFor("Quantitative Aptitude")
                val reasoningPercent = pctFor("Reasoning")
                val englishPercent = pctFor("English")

                tvQuantitative.text = "Quantitative Aptitude: $quantPercent%"
                tvReasoning.text = "Reasoning: $reasoningPercent%"
                tvEnglish.text = "English: $englishPercent%"

                val overallPercent = if (totalMarks > 0) (totalScore * 100) / totalMarks else 0
                tvOverallPercentage.text = "Overall: $overallPercent%"

                // Since there is no topic info, show N/A with guidance
                val naMessage = "N/A — topic not tracked in results"
                tvQuantitativeSummary.text = naMessage
                tvReasoningSummary.text = naMessage
                tvEnglishSummary.text = naMessage

                profileDbHelper.insertOrUpdateProfile(username, "N/A", overallPercent.toDouble())
            } else {
                // no results at all
                tvQuantitative.text = "Quantitative Aptitude: N/A"
                tvReasoning.text = "Reasoning: N/A"
                tvEnglish.text = "English: N/A"
                tvOverallPercentage.text = "Overall: N/A"

                val naMessage = "N/A — no data"
                tvQuantitativeSummary.text = naMessage
                tvReasoningSummary.text = naMessage
                tvEnglishSummary.text = naMessage
            }
        }

        edb.close()
    }
}
