package com.example.competitiveexampreparationapp


import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.example.competitiveexampreparationapp.R


class ScoresActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_scores)


        val subjectWiseBtn: Button = findViewById(R.id.button)
        val totalScoresBtn: Button = findViewById(R.id.button2)
        val percentageBtn: Button = findViewById(R.id.button3)
        val competencyBtn: Button = findViewById(R.id.button4)
        val resultBtn: Button = findViewById(R.id.button5)


        subjectWiseBtn.setOnClickListener {
            startActivity(Intent(this, Marks::class.java))
        }


        totalScoresBtn.setOnClickListener {
            startActivity(Intent(this, Totalscores::class.java))
        }


        percentageBtn.setOnClickListener {
            startActivity(Intent(this, Percentage::class.java))
        }


        competencyBtn.setOnClickListener {
            startActivity(Intent(this, Competency::class.java))
        }


        resultBtn.setOnClickListener {
            startActivity(Intent(this, Result::class.java))
        }
    }
}


