package com.example.competitiveexampreparationapp

data class SubjectProgress(
    val name: String,
    val scoreText: String,
    val progress: Int

)

