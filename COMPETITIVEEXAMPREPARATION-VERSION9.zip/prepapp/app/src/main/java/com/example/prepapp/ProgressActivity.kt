package com.example.competitiveexampreparationapp

import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class ProgressActivity : AppCompatActivity() {

    private lateinit var spinnerSubject: Spinner
    private lateinit var spinnerSort: Spinner
    private lateinit var lvProgress: ListView
    private lateinit var dbHelper: ExamDBHelper
    private lateinit var userDB: UserDBHelper
    private lateinit var allResults: List<ExamResult>
    private lateinit var adapter: ProgressAdapter
    private var username: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_progress)

        spinnerSubject = findViewById(R.id.spinner_Subject)
        spinnerSort = findViewById(R.id.spinner_Sort)
        lvProgress = findViewById(R.id.lvProgress)
        dbHelper = ExamDBHelper(this)
        userDB = UserDBHelper(this)

        // Get the last logged-in username
        username = userDB.getLastUsername() ?: run {
            Toast.makeText(this, "User not found. Please login.", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        // Load all results for this user
        allResults = dbHelper.getAllResults(username)

        // Setup adapter
        adapter = ProgressAdapter(this, allResults)
        lvProgress.adapter = adapter

        setupSpinners()
    }

    private fun setupSpinners() {
        // Subjects: "All" + distinct subjects from allResults
        val subjects = listOf("All") + allResults.map { it.subject }.distinct()
        val subjectAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, subjects)
        subjectAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerSubject.adapter = subjectAdapter

        // Sort options
        val sortOptions = listOf("Newest First", "Oldest First")
        val sortAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, sortOptions)
        sortAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerSort.adapter = sortAdapter

        // Listener for both spinners
        val listener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                applyFilters()
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        spinnerSubject.onItemSelectedListener = listener
        spinnerSort.onItemSelectedListener = listener
    }

    private fun applyFilters() {
        var filtered = allResults

        // Filter by subject
        val selectedSubject = spinnerSubject.selectedItem.toString()
        if (selectedSubject != "All") {
            filtered = filtered.filter { it.subject == selectedSubject }
        }

        // Sort by date
        filtered = if (spinnerSort.selectedItem.toString() == "Newest First") {
            filtered.sortedByDescending { it.date }
        } else {
            filtered.sortedBy { it.date }
        }

        // Update adapter
        adapter = ProgressAdapter(this, filtered)
        lvProgress.adapter = adapter
    }
}
