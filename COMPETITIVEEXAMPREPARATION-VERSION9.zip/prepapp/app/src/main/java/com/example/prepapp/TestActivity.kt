package com.example.competitiveexampreparationapp

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.os.CountDownTimer
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.util.*

class TestActivity : AppCompatActivity() {

    private lateinit var examDB: ExamDBHelper
    private lateinit var reportDB: ReportDBHelper
    private lateinit var userId: String
    private lateinit var subject: String

    private lateinit var questions: MutableList<Question>
    private var currentIndex = 0
    private val answers = mutableMapOf<Int, Int>()
    private var timer: CountDownTimer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_test)

        val userDB = UserDBHelper(this)
        examDB = ExamDBHelper(this)
        reportDB = ReportDBHelper(this)

        userId = userDB.getLastUsername() ?: run {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            return
        }

        subject = intent.getStringExtra("subject") ?: "Quantitative Aptitude"
        val allQuestions = examDB.getQuestionsBySubject(subject)
        questions = allQuestions.shuffled().take(10).toMutableList()

        if (questions.isEmpty()) {
            Toast.makeText(this, "No questions for $subject", Toast.LENGTH_LONG).show()
            finish()
            return
        }

        setupQuestionView()
        startTimer(15)
    }

    private fun setupQuestionView() {
        showQuestion(currentIndex)

        findViewById<Button>(R.id.btnNext).setOnClickListener {
            saveAnswer()
            if (currentIndex < questions.lastIndex) {
                currentIndex++
                showQuestion(currentIndex)
            }
        }

        findViewById<Button>(R.id.btnPrev).setOnClickListener {
            saveAnswer()
            if (currentIndex > 0) {
                currentIndex--
                showQuestion(currentIndex)
            }
        }

        findViewById<Button>(R.id.btnSubmit).setOnClickListener {
            confirmSubmit()
        }
    }

    private fun showQuestion(index: Int) {
        val q = questions[index]
        findViewById<TextView>(R.id.tvQuestion).text = "${index + 1}. ${q.text}"
        val rg = findViewById<RadioGroup>(R.id.optionsGroup)
        rg.removeAllViews()

        q.options.forEach { opt ->
            val rb = RadioButton(this)
            rb.id = View.generateViewId()
            rb.text = opt
            rg.addView(rb)
        }

        answers[q.id]?.let { (rg.getChildAt(it) as? RadioButton)?.isChecked = true }
    }

    private fun saveAnswer() {
        val q = questions[currentIndex]
        val rg = findViewById<RadioGroup>(R.id.optionsGroup)
        val idx = rg.indexOfChild(findViewById(rg.checkedRadioButtonId))
        if (idx >= 0) answers[q.id] = idx
    }

    private fun confirmSubmit() {
        saveAnswer()
        AlertDialog.Builder(this)
            .setTitle("Submit Test")
            .setMessage("Are you sure you want to submit?")
            .setPositiveButton("Submit") { _, _ -> saveAndGoToResult() }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun saveAndGoToResult() {
        timer?.cancel()

        // Save each answer in reportDB
        questions.forEach { q ->
            val userAns = answers[q.id] ?: -1
            reportDB.insertAttempt(userId, subject, q.id, q.text, q.options, q.correctIndex, userAns)
        }

        // Calculate score
        val correct = questions.count { (answers[it.id] ?: -1) == it.correctIndex }
        val total = questions.size
        val now = System.currentTimeMillis()

        // Save test result in ExamDBHelper
        examDB.saveResult(userId, subject, correct, total, now)

        // Go to ResultActivity
        val intent = Intent(this, ResultActivity::class.java).apply {
            putExtra("score", correct)
            putExtra("total", total)
            putExtra("userId", userId)
            putExtra("subject", subject)
        }
        startActivity(intent)
        finish()
    }

    private fun startTimer(minutes: Int) {
        val tvTimer = findViewById<TextView>(R.id.tvTimer)
        val totalMillis = minutes * 60 * 1000L

        timer = object : CountDownTimer(totalMillis, 1000) {
            override fun onTick(ms: Long) {
                val s = ms / 1000
                tvTimer.text = String.format(Locale.getDefault(), "%02d:%02d", s / 60, s % 60)
            }

            override fun onFinish() {
                Toast.makeText(this@TestActivity, "Time's up!", Toast.LENGTH_SHORT).show()
                saveAndGoToResult()
            }
        }.start()
    }

    override fun onDestroy() {
        timer?.cancel()
        examDB.close()
        reportDB.close()
        super.onDestroy()
    }
}
