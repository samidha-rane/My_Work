package com.example.competitiveexampreparationapp

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONArray

data class QuestionAttempt(
    val questionId: Int,
    val questionText: String,
    val options: List<String>,
    val correctIndex: Int,
    val userAnswer: Int
)

class ReportDBHelper(context: Context) : SQLiteOpenHelper(context, "UserReports.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        val createTable = """
            CREATE TABLE UserTestAttempt (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                userId TEXT,
                subject TEXT,
                questionId INTEGER,
                questionText TEXT,
                options TEXT,
                correctIndex INTEGER,
                userAnswer INTEGER,
                timestamp INTEGER
            )
        """.trimIndent()
        db.execSQL(createTable)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS UserTestAttempt")
        onCreate(db)
    }

    fun insertAttempt(
        userId: String,
        subject: String,
        questionId: Int,
        questionText: String,
        options: List<String>,
        correctIndex: Int,
        userAnswer: Int
    ) {
        val db = writableDatabase
        val cv = ContentValues().apply {
            put("userId", userId)
            put("subject", subject)
            put("questionId", questionId)
            put("questionText", questionText)
            put("options", JSONArray(options).toString())
            put("correctIndex", correctIndex)
            put("userAnswer", userAnswer)
            put("timestamp", System.currentTimeMillis())
        }
        db.insert("UserTestAttempt", null, cv)
        db.close()
    }

    fun getAttemptsForUser(userId: String, subject: String): List<QuestionAttempt> {
        val db = readableDatabase
        val cursor = db.rawQuery(
            "SELECT questionId, questionText, options, correctIndex, userAnswer FROM UserTestAttempt WHERE userId=? AND subject=? ORDER BY timestamp ASC",
            arrayOf(userId, subject)
        )

        val list = mutableListOf<QuestionAttempt>()
        while (cursor.moveToNext()) {
            val questionId = cursor.getInt(0)
            val questionText = cursor.getString(1)
            val optionsJson = cursor.getString(2)
            val options = JSONArray(optionsJson).let { json ->
                List(json.length()) { i -> json.getString(i) }
            }
            val correctIndex = cursor.getInt(3)
            val userAnswer = cursor.getInt(4)
            list.add(QuestionAttempt(questionId, questionText, options, correctIndex, userAnswer))
        }
        cursor.close()
        db.close()
        return list
    }
    fun getLatestUserId(): String? {
        val db = readableDatabase
        val cursor = db.rawQuery(
            "SELECT userId FROM UserTestAttempt ORDER BY timestamp DESC LIMIT 1",
            null
        )
        var userId: String? = null
        if (cursor.moveToFirst()) {
            userId = cursor.getString(0)
        }
        cursor.close()
        db.close()
        return userId
    }

    fun getAllUsers(): List<String> {
        val db = readableDatabase
        val cursor = db.rawQuery(
            "SELECT DISTINCT userId FROM UserTestAttempt",
            null
        )
        val users = mutableListOf<String>()
        while (cursor.moveToNext()) {
            users.add(cursor.getString(0))
        }
        cursor.close()
        db.close()
        return users
    }

    fun getLatestAttemptForUser(userId: String, subject: String): List<QuestionAttempt> {
        val db = readableDatabase
        val cursor = db.rawQuery(
            """
        SELECT questionId, questionText, options, correctIndex, userAnswer 
        FROM UserTestAttempt 
        WHERE userId=? AND subject=? 
        ORDER BY timestamp DESC, id DESC 
        LIMIT 10
        """.trimIndent(),
            arrayOf(userId, subject)
        )

        val list = mutableListOf<QuestionAttempt>()
        while (cursor.moveToNext()) {
            val questionId = cursor.getInt(0)
            val questionText = cursor.getString(1)
            val optionsJson = cursor.getString(2)
            val options = JSONArray(optionsJson).let { json ->
                List(json.length()) { i -> json.getString(i) }
            }
            val correctIndex = cursor.getInt(3)
            val userAnswer = cursor.getInt(4)
            list.add(QuestionAttempt(questionId, questionText, options, correctIndex, userAnswer))
        }
        cursor.close()
        db.close()
        return list.reversed() // To show in original order of questions
    }

}
