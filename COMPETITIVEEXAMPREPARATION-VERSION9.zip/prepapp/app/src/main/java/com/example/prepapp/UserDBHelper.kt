package com.example.competitiveexampreparationapp

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.util.*

class UserDBHelper(context: Context) :
    SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "UserDB.db"
        private const val DATABASE_VERSION = 1
        private const val TABLE_USERS = "users"
        private const val COL_ID = "id"
        private const val COL_FIRSTNAME = "firstname"
        private const val COL_LASTNAME = "lastname"
        private const val COL_USERNAME = "username"
        private const val COL_PASSWORD = "password"
    }

    override fun onCreate(db: SQLiteDatabase) {
        val createTable = """
            CREATE TABLE $TABLE_USERS (
                $COL_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_FIRSTNAME TEXT NOT NULL,
                $COL_LASTNAME TEXT NOT NULL,
                $COL_USERNAME TEXT UNIQUE NOT NULL,
                $COL_PASSWORD TEXT NOT NULL
            );
        """.trimIndent()
        db.execSQL(createTable)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_USERS")
        onCreate(db)
    }

    // Generate username & password
    fun generateUsernamePassword(firstName: String, lastName: String): Pair<String, String> {
        val random = Random()
        val username = firstName.take(4).lowercase() + (1000 + random.nextInt(9000))
        val password = lastName.take(4).lowercase() + (10000 + random.nextInt(90000))
        return Pair(username, password)
    }

    // Insert user
    fun insertUser(firstName: String, lastName: String): Pair<String, String>? {
        val db = writableDatabase
        val (username, password) = generateUsernamePassword(firstName, lastName)
        val values = ContentValues().apply {
            put(COL_FIRSTNAME, firstName)
            put(COL_LASTNAME, lastName)
            put(COL_USERNAME, username)
            put(COL_PASSWORD, password)
        }
        val result = db.insert(TABLE_USERS, null, values)
        db.close()
        return if (result == -1L) null else Pair(username, password)
    }

    // Check login credentials
    fun checkLogin(username: String, password: String): Boolean {
        val db = readableDatabase
        val cursor = db.rawQuery(
            "SELECT 1 FROM $TABLE_USERS WHERE $COL_USERNAME=? AND $COL_PASSWORD=?",
            arrayOf(username, password)
        )
        val exists = cursor.count > 0
        cursor.close()
        db.close()
        return exists
    }

    // Update user password
    fun updatePassword(username: String, newPassword: String): Boolean {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COL_PASSWORD, newPassword)
        }
        val rows = db.update(TABLE_USERS, values, "$COL_USERNAME=?", arrayOf(username))
        db.close()
        return rows > 0
    }

    // Check if user exists
    fun isUserExists(username: String): Boolean {
        val db = readableDatabase
        val cursor = db.rawQuery(
            "SELECT 1 FROM $TABLE_USERS WHERE $COL_USERNAME=?",
            arrayOf(username)
        )
        val exists = cursor.count > 0
        cursor.close()
        db.close()
        return exists
    }

    // Get last username (for autofill, optional)
    fun getLastUsername(): String? {
        val db = readableDatabase
        val cursor = db.rawQuery(
            "SELECT $COL_USERNAME FROM $TABLE_USERS ORDER BY $COL_ID DESC LIMIT 1",
            null
        )
        val username = if (cursor.moveToFirst()) cursor.getString(0) else null
        cursor.close()
        db.close()
        return username
    }
}
