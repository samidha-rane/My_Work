package com.example.competitiveexampreparationapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth

class ResetPasswordActivity : AppCompatActivity() {

    private lateinit var etResetEmail: EditText
    private lateinit var btnSendResetLink: Button
    private lateinit var btnReturnLogin: Button
    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_reset_password)

        etResetEmail = findViewById(R.id.etResetUsername)   // make sure your XML id matches
        btnSendResetLink = findViewById(R.id.btnUpdatePassword)
        btnReturnLogin = findViewById(R.id.btnReturnLogin)

        auth = FirebaseAuth.getInstance()

        // ✅ Send reset link
        btnSendResetLink.setOnClickListener {
            val email = etResetEmail.text.toString().trim()

            if (email.isEmpty()) {
                Toast.makeText(this, "Enter your registered email", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            auth.sendPasswordResetEmail(email)
                .addOnSuccessListener {
                    Toast.makeText(
                        this,
                        "Reset link sent to $email. Please check your inbox.",
                        Toast.LENGTH_LONG
                    ).show()
                    goToLogin()
                }
                .addOnFailureListener { e ->
                    Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_LONG).show()
                }
        }

        // ✅ Return to login
        btnReturnLogin.setOnClickListener {
            goToLogin()
        }
    }

    private fun goToLogin() {
        startActivity(Intent(this, LoginActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
        })
        finish()
    }
}
