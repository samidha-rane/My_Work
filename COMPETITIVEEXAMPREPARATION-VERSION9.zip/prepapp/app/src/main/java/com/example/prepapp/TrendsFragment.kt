package com.example.competitiveexampreparationapp

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.example.competitiveexampreparationapp.R
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet

class TrendsFragment : Fragment() {

    private lateinit var lineChart: LineChart

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.trends_fragment, container, false)
        lineChart = view.findViewById(R.id.lineChart)
        setupLineChart()
        return view
    }

    private fun setupLineChart() {
        val entries = listOf(
            Entry(1f, 60f),
            Entry(2f, 65f),
            Entry(3f, 70f),
            Entry(4f, 75f),
            Entry(5f, 80f)
        )

        val dataSet = LineDataSet(entries, "Score Over Time").apply {
            color = resources.getColor(android.R.color.holo_blue_dark, null)
            valueTextSize = 10f
            lineWidth = 2f
            circleRadius = 4f
            setCircleColor(resources.getColor(android.R.color.holo_blue_dark, null))
        }

        lineChart.data = LineData(dataSet)
        lineChart.axisRight.isEnabled = false
        lineChart.description.isEnabled = false

        val xAxis = lineChart.xAxis
        xAxis.position = XAxis.XAxisPosition.BOTTOM
        xAxis.granularity = 1f
        xAxis.setDrawGridLines(false)

        lineChart.invalidate()
    }
}
