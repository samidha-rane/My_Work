package com.example.competitiveexampreparationapp

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.competitiveexampreparationapp.R

//data class TestAttempt(
//    val date: String,          // e.g., "2025-09-14"
//    val subject: String,       // e.g., "Quantitative Aptitude"
//    val score: Int,            // 0..100
//    val improved: Boolean? = null // true = improved, false = decreased, null = first attempt
//) {
//    val scoreText: String
//        get() {
//            val arrow = when (improved) {
//                true -> " ↑"
//                false -> " ↓"
//                null -> ""
//            }
//            return "$score/100 Marks$arrow"
//        }
//}

class TestHistoryAdapter(
    private var list: List<TestAttempt>
) : RecyclerView.Adapter<TestHistoryAdapter.VH>() {

    class VH(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvDate: TextView = itemView.findViewById(R.id.tvDate)
        val tvSubject: TextView = itemView.findViewById(R.id.tvSubjectName)
        val tvScore: TextView = itemView.findViewById(R.id.tvScoreText)
        val progressBar: ProgressBar = itemView.findViewById(R.id.subjectProgressBar)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_test, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = list[position]
        holder.tvDate.text = item.date
        holder.tvSubject.text = item.subject
        holder.progressBar.progress = item.score
        holder.tvScore.text = item.scoreText

        holder.tvScore.setTextColor(
            when (item.improved) {
                true -> Color.parseColor("#4CAF50")
                false -> Color.parseColor("#F44336")
                else -> Color.BLACK
            }
        )
    }

    override fun getItemCount(): Int = list.size

    // ✅ Add this method
    fun updateData(newList: List<TestAttempt>) {
        list = newList
        notifyDataSetChanged()
    }
}
