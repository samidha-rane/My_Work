package com.example.competitiveexampreparationapp

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity
import com.example.competitiveexampreparationapp.R


class SubjectSelectionActivity : AppCompatActivity() {
    private val subjects = listOf("Quantitative Aptitude", "Reasoning", "English")


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_subject_selection)


        val listView = findViewById<ListView>(R.id.subjectListView)
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, subjects)
        listView.adapter = adapter


        listView.setOnItemClickListener { _, _, position, _ ->
            val subject = subjects[position]
            val intent = Intent(this, InstructionsActivity::class.java)
            intent.putExtra("subject", subject)
            startActivity(intent)
        }
    }
}