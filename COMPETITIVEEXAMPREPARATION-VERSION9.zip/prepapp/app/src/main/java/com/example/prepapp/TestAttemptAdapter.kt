package com.example.competitiveexampreparationapp

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.competitiveexampreparationapp.R
import com.google.android.material.progressindicator.LinearProgressIndicator

class TestAttemptAdapter(
    private var list: List<TestAttempt> // 🔄 Made mutable (via update method)
) : RecyclerView.Adapter<TestAttemptAdapter.VH>() {

    class VH(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvDate: TextView = itemView.findViewById(R.id.tvDate)
        val tvSubject: TextView = itemView.findViewById(R.id.tvSubjectName)
        val tvScore: TextView = itemView.findViewById(R.id.tvScoreText)
        val progressBar: LinearProgressIndicator = itemView.findViewById(R.id.subjectProgressBar)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_test_attempt, parent, false)
        return VH(view)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = list[position]
        holder.tvDate.text = item.date
        holder.tvSubject.text = item.subject
        holder.tvScore.text = item.scoreText
        holder.progressBar.progress = item.score

        holder.tvScore.setTextColor(
            when (item.improved) {
                true -> Color.parseColor("#4CAF50") // green for improved
                false -> Color.parseColor("#F44336") // red for declined
                else -> Color.BLACK // default
            }
        )
    }

    override fun getItemCount(): Int = list.size

    // ✅ Add this to support real-time updates
    fun updateData(newList: List<TestAttempt>) {
        list = newList
        notifyDataSetChanged()
    }
}
