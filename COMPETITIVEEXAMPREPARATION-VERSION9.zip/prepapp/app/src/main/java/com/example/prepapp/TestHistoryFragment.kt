package com.example.competitiveexampreparationapp

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.competitiveexampreparationapp.R

class TestHistoryFragment : Fragment() {

    private lateinit var rvTestHistory: RecyclerView
    private lateinit var adapter: TestHistoryAdapter
    private lateinit var dbHelper: DBHelper
    private lateinit var userId: String

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val view = inflater.inflate(R.layout.fragment_test_history, container, false)
        rvTestHistory = view.findViewById(R.id.rvTestHistory)
        rvTestHistory.layoutManager = LinearLayoutManager(requireContext())

        dbHelper = DBHelper(requireContext())

        val prefs = requireContext().getSharedPreferences("UserPrefs", Context.MODE_PRIVATE)
        userId = prefs.getString("username", "") ?: ""

        adapter = TestHistoryAdapter(emptyList()) // Start with empty list
        rvTestHistory.adapter = adapter

        return view
    }

    override fun onResume() {
        super.onResume()
        refreshTestAttempts()
    }

    private fun refreshTestAttempts() {
        val updatedAttempts = dbHelper.getTestsForUser(userId)
        adapter.updateData(updatedAttempts)
    }
}


