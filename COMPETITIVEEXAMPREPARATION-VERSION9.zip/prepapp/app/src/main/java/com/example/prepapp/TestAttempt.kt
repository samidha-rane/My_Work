package com.example.competitiveexampreparationapp

data class TestAttempt(
    val date: String,
    val subject: String,
    val score: Int,
    val improved: Boolean? = null
) {
    val scoreText: String
        get() {
            val arrow = when (improved) {
                true -> " ↑"
                false -> " ↓"
                null -> ""
            }
            return "$score%$arrow"
        }
}

