package com.example.competitiveexampreparationapp

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.competitiveexampreparationapp.R

class Result : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_result1)

        val subjectInput: EditText = findViewById(R.id.inputSubject)
        val checkButton: Button = findViewById(R.id.checkResultBtn)
        val resultOutput: TextView = findViewById(R.id.resultOutput)

        val dbHelper = ReportDBHelper(this)

        // ✅ Fetch latest user dynamically
        val userId = dbHelper.getLatestUserId()

        if (userId == null) {
            resultOutput.text = "No data found"
            return
        }

        checkButton.setOnClickListener {
            val subject = subjectInput.text.toString().trim()

            if (subject.isNotEmpty()) {
                val attempts = dbHelper.getAttemptsForUser(userId, subject)
                val totalCorrect = attempts.count { it.userAnswer == it.correctIndex }
                val totalQuestions = attempts.size
                val percentage =
                    if (totalQuestions > 0) (totalCorrect * 100) / totalQuestions else 0

                resultOutput.text =
                    "$subject Result:\nScore: $totalCorrect / $totalQuestions\nPercentage: $percentage%"
            } else {
                resultOutput.text = "Please enter a subject."
            }
        }
    }
}
