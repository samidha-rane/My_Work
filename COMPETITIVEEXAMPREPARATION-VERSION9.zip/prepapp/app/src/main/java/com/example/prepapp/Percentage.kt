package com.example.competitiveexampreparationapp

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.competitiveexampreparationapp.R

class Percentage : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_percentage)

        val percentageText: TextView = findViewById(R.id.percentageTextView)

        val dbHelper = ReportDBHelper(this)

        // ✅ Get latest userId dynamically
        val userId = dbHelper.getLatestUserId()

        if (userId == null) {
            percentageText.text = getString(R.string.no_attempts)
            return
        }

        // You can pick any subject or loop subjects
        val subject = "Quantitative Aptitude"
        val attempts = dbHelper.getAttemptsForUser(userId, subject)

        val total = attempts.size
        val correct = attempts.count { it.userAnswer == it.correctIndex }

        if (total > 0) {
            val percentage = (correct.toDouble() / total.toDouble() * 100).toInt()
            percentageText.text = getString(R.string.percentage_result, percentage)
        } else {
            percentageText.text = getString(R.string.no_attempts)
        }
    }
}
