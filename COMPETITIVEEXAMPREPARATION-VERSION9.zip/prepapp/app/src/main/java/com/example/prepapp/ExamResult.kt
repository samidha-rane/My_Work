package com.example.competitiveexampreparationapp

data class ExamResult(
    val subject: String,
    val score: Int,
    val total: Int,
    val date: Long
)