package com.example.competitiveexampreparationapp

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONArray

class ExamDBHelper(context: Context) : SQLiteOpenHelper(context, DB_NAME, null, DB_VERSION) {

    companion object {
        private const val DB_NAME = "exam_app.db"
        private const val DB_VERSION = 7 // updated for sample questions

        const val TABLE_QUESTIONS = "questions"
        const val TABLE_RESULTS = "results"

        // Question columns
        private const val COL_Q_ID = "id"
        private const val COL_Q_SUBJECT = "subject"
        private const val COL_Q_TEXT = "text"
        private const val COL_Q_OPTIONS = "options"
        private const val COL_Q_CORRECT = "correct_index"

        // Result columns
        private const val COL_R_ID = "id"
        private const val COL_R_USERNAME = "username"
        private const val COL_R_SUBJECT = "subject"
        private const val COL_R_SCORE = "score"
        private const val COL_R_TOTAL = "total"
        private const val COL_R_DATE = "date"
    }

    override fun onCreate(db: SQLiteDatabase) {
        val createQuestions = """
            CREATE TABLE $TABLE_QUESTIONS (
                $COL_Q_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_Q_SUBJECT TEXT,
                $COL_Q_TEXT TEXT,
                $COL_Q_OPTIONS TEXT,
                $COL_Q_CORRECT INTEGER
            );
        """.trimIndent()

        val createResults = """
            CREATE TABLE $TABLE_RESULTS (
                $COL_R_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_R_USERNAME TEXT,
                $COL_R_SUBJECT TEXT,
                $COL_R_SCORE INTEGER,
                $COL_R_TOTAL INTEGER,
                $COL_R_DATE LONG
            );
        """.trimIndent()

        db.execSQL(createQuestions)
        db.execSQL(createResults)

        insertSampleQuestions(db)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_QUESTIONS")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_RESULTS")
        onCreate(db)
    }

    private fun insertSampleQuestions(db: SQLiteDatabase) {
        val questions = listOf(
            // ----------------- Quantitative Aptitude (20) -----------------
            Triple("Quantitative Aptitude", "What is 12 × 8 ?", listOf("96", "92", "86", "108") to 0),
            Triple("Quantitative Aptitude", "Square root of 144 is?", listOf("10", "11", "12", "14") to 2),
            Triple("Quantitative Aptitude", "What is 25% of 200?", listOf("25", "50", "100", "75") to 1),
            Triple("Quantitative Aptitude", "Simplify: 150 ÷ 5 × 2", listOf("50", "60", "70", "75") to 1),
            Triple("Quantitative Aptitude", "Average of 10, 20, 30, 40?", listOf("20", "25", "30", "35") to 1),
            Triple("Quantitative Aptitude", "LCM of 6 and 8?", listOf("12", "18", "24", "48") to 2),
            Triple("Quantitative Aptitude", "HCF of 36 and 48?", listOf("6", "12", "18", "24") to 1),
            Triple("Quantitative Aptitude", "What is 15% of 400?", listOf("50", "55", "60", "65") to 2),
            Triple("Quantitative Aptitude", "If CP = 100, SP = 120, Profit %?", listOf("10%", "15%", "20%", "25%") to 2),
            Triple("Quantitative Aptitude", "Solve: (20 + 30) ÷ 10", listOf("3", "4", "5", "6") to 2),
            Triple("Quantitative Aptitude", "Area of square with side 5?", listOf("20", "25", "30", "35") to 1),
            Triple("Quantitative Aptitude", "Perimeter of rectangle 4×6?", listOf("20", "24", "28", "32") to 1),
            Triple("Quantitative Aptitude", "Speed = 60 km/h, Distance = 120 km, Time?", listOf("1 hr", "1.5 hr", "2 hr", "2.5 hr") to 2),
            Triple("Quantitative Aptitude", "What is 2³ × 3²?", listOf("18", "24", "36", "72") to 2),
            Triple("Quantitative Aptitude", "Solve: 7² – 5²", listOf("12", "20", "24", "36") to 2),
            Triple("Quantitative Aptitude", "Simple Interest on 1000 at 10% for 2 years?", listOf("100", "150", "200", "250") to 2),
            Triple("Quantitative Aptitude", "Ratio of 2:3 equivalent to?", listOf("4:6", "6:9", "8:12", "All of these") to 3),
            Triple("Quantitative Aptitude", "Median of 2,4,6,8,10?", listOf("4", "5", "6", "7") to 2),
            Triple("Quantitative Aptitude", "What is 15 × 14?", listOf("190", "200", "210", "220") to 2),
            Triple("Quantitative Aptitude", "Cube of 5?", listOf("25", "100", "125", "150") to 2),

            // ----------------- Reasoning (20) -----------------
            Triple("Reasoning", "Find the next in sequence: 2, 6, 12, 20, ?", listOf("30", "28", "26", "24") to 1),
            Triple("Reasoning", "If CAT = 24, DOG = ?", listOf("26", "28", "30", "32") to 2),
            Triple("Reasoning", "Odd one out: Apple, Mango, Banana, Carrot", listOf("Apple", "Mango", "Banana", "Carrot") to 3),
            Triple("Reasoning", "Opposite of 'North-East'?", listOf("South-West", "South-East", "North-West", "North") to 0),
            Triple("Reasoning", "Series: A, C, E, G, ?", listOf("H", "I", "J", "K") to 2),
            Triple("Reasoning", "If 5+3=28, 6+2=36, 7+1=?", listOf("40", "42", "48", "56") to 1),
            Triple("Reasoning", "Find the missing number in the series: 5, 10, 20, 40, ?", listOf("60", "70", "80", "100") to 3),
            Triple("Reasoning", "Find missing number: 3, 9, 27, ?", listOf("54", "72", "81", "90") to 2),
            Triple("Reasoning", "Mirror of 123 is?", listOf("321", "132", "213", "231") to 0),
            Triple("Reasoning", "Which is different? Circle, Triangle, Square, Cube", listOf("Circle", "Triangle", "Square", "Cube") to 3),
            Triple("Reasoning", "If 'EARTH' = 52, 'MOON' = ?", listOf("56", "62", "64", "72") to 2),
            Triple("Reasoning", "Next: 2, 4, 8, 16, ?", listOf("24", "30", "32", "36") to 2),
            Triple("Reasoning", "If A=1, B=2, Z=26, then AZ=?", listOf("27", "28", "29", "30") to 0),
            Triple("Reasoning", "Find odd one out: Rose, Lily, Lotus, Mango", listOf("Rose", "Lily", "Lotus", "Mango") to 3),
            Triple("Reasoning", "Which is heavier? 1 kg cotton or 1 kg iron", listOf("Cotton", "Iron", "Equal", "None") to 2),
            Triple("Reasoning", "Which comes next: 11, 13, 17, 19, ?", listOf("20", "21", "23", "25") to 2),
            Triple("Reasoning", "Select related word: Book: Author :: Paint: ?", listOf("Painter", "Brush", "Color", "Canvas") to 0),
            Triple("Reasoning", "If ALL = 27, BAT = ?", listOf("43", "44", "45", "46") to 1),
            Triple("Reasoning", "Odd one out: Pen, Pencil, Eraser, Chair", listOf("Pen", "Pencil", "Eraser", "Chair") to 3),
            Triple("Reasoning", "Cube has how many edges?", listOf("10", "12", "14", "16") to 1),

            // ----------------- English (20) -----------------
            Triple("English", "Choose the correct synonym for 'Happy'", listOf("Sad", "Joyful", "Angry", "Upset") to 1),
            Triple("English", "Antonym of 'Fast'?", listOf("Quick", "Rapid", "Slow", "Speedy") to 2),
            Triple("English", "Fill in the blank: She ____ to school daily.", listOf("go", "goes", "going", "gone") to 1),
            Triple("English", "Plural of 'Child'?", listOf("Childs", "Children", "Childes", "Childrens") to 1),
            Triple("English", "Past tense of 'Eat'?", listOf("Eated", "Eaten", "Ate", "Eating") to 2),
            Triple("English", "Choose correct article: He bought ___ apple.", listOf("a", "an", "the", "no article") to 1),
            Triple("English", "Correct spelling?", listOf("Recieve", "Receive", "Receeve", "Receve") to 1),
            Triple("English", "Antonym of 'Hot'?", listOf("Cold", "Warm", "Cool", "Freeze") to 0),
            Triple("English", "Synonym of 'Begin'?", listOf("End", "Start", "Close", "Finish") to 1),
            Triple("English", "Fill in the blank: They ____ playing.", listOf("is", "am", "are", "was") to 2),
            Triple("English", "One word: 'A place to study books'", listOf("Library", "School", "Class", "Hall") to 0),
            Triple("English", "Choose the correct: I ____ a car.", listOf("has", "have", "having", "had") to 1),
            Triple("English", "Opposite of 'Tall'?", listOf("Small", "Short", "Little", "Low") to 1),
            Triple("English", "Synonym of 'Big'?", listOf("Huge", "Tiny", "Small", "Little") to 0),
            Triple("English", "Past tense of 'Go'?", listOf("Goes", "Gone", "Went", "Going") to 2),
            Triple("English", "Choose the correct: The sun ____ in the east.", listOf("rise", "rises", "rising", "rose") to 1),
            Triple("English", "Fill in the blank: I am ____ my homework.", listOf("do", "did", "doing", "done") to 2),
            Triple("English", "Correct spelling?", listOf("Occured", "Occurred", "Ocurred", "Occurrd") to 1),
            Triple("English", "Antonym of 'Brave'?", listOf("Strong", "Cowardly", "Fearless", "Heroic") to 1),
            Triple("English", "Synonym of 'Friend'?", listOf("Enemy", "Mate", "Foe", "Stranger") to 1)
        )

        for (q in questions) {
            val values = ContentValues().apply {
                put(COL_Q_SUBJECT, q.first)
                put(COL_Q_TEXT, q.second)
                put(COL_Q_OPTIONS, JSONArray(q.third.first).toString())
                put(COL_Q_CORRECT, q.third.second)
            }
            db.insert(TABLE_QUESTIONS, null, values)
        }
    }

    fun getQuestionsBySubject(subject: String): List<Question> {
        val list = mutableListOf<Question>()
        readableDatabase.rawQuery(
            "SELECT $COL_Q_ID,$COL_Q_SUBJECT,$COL_Q_TEXT,$COL_Q_OPTIONS,$COL_Q_CORRECT FROM $TABLE_QUESTIONS WHERE $COL_Q_SUBJECT=? ORDER BY RANDOM() LIMIT 10",
            arrayOf(subject)
        ).use { c ->
            while (c.moveToNext()) {
                val options = JSONArray(c.getString(3)).let { arr -> List(arr.length()) { i -> arr.getString(i) } }
                list.add(Question(c.getInt(0), c.getString(1), c.getString(2), options, c.getInt(4)))
            }
        }
        return list
    }

    fun saveResult(username: String, subject: String, score: Int, total: Int, date: Long) {
        writableDatabase.insert(TABLE_RESULTS, null, ContentValues().apply {
            put(COL_R_USERNAME, username)
            put(COL_R_SUBJECT, subject)
            put(COL_R_SCORE, score)
            put(COL_R_TOTAL, total)
            put(COL_R_DATE, date)
        })
    }

    fun getAllResults(username: String): List<ExamResult> {
        val list = mutableListOf<ExamResult>()
        readableDatabase.rawQuery(
            "SELECT $COL_R_SUBJECT,$COL_R_SCORE,$COL_R_TOTAL,$COL_R_DATE FROM $TABLE_RESULTS WHERE $COL_R_USERNAME=? ORDER BY $COL_R_DATE DESC",
            arrayOf(username)
        ).use { c ->
            while (c.moveToNext()) {
                list.add(
                    ExamResult(
                        subject = c.getString(0),
                        score = c.getInt(1),
                        total = c.getInt(2),
                        date = c.getLong(3)
                    )
                )
            }
        }
        return list
    }
}
