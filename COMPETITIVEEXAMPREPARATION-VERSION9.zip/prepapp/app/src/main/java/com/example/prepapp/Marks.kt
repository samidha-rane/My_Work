package com.example.competitiveexampreparationapp

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.competitiveexampreparationapp.R

class Marks : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_marks)

        val dbHelper = ReportDBHelper(this)

        // Get latest userId from DB
        val userId = dbHelper.getLatestUserId()

        if (userId == null) {
            // No attempts found in DB
            val quantMarks: TextView = findViewById(R.id.quantMarks)
            val reasoningMarks: TextView = findViewById(R.id.reasoningMarks)
            val englishMarks: TextView = findViewById(R.id.englishMarks)

            quantMarks.text = "No data found"
            reasoningMarks.text = "No data found"
            englishMarks.text = "No data found"
            return
        }

        // Subjects
        val subjects = listOf("Quantitative Aptitude", "Reasoning", "English")

        // TextViews
        val quantMarks: TextView = findViewById(R.id.quantMarks)
        val reasoningMarks: TextView = findViewById(R.id.reasoningMarks)
        val englishMarks: TextView = findViewById(R.id.englishMarks)

        // Update each subject
        for (subject in subjects) {
            val attempts = dbHelper.getAttemptsForUser(userId, subject)
            val totalCorrect = attempts.count { it.userAnswer == it.correctIndex }
            val totalQuestions = attempts.size

            when (subject) {
                "Quantitative Aptitude" -> quantMarks.text =
                    "Quantitative Aptitude: $totalCorrect / $totalQuestions"
                "Reasoning" -> reasoningMarks.text =
                    "Reasoning: $totalCorrect / $totalQuestions"
                "English" -> englishMarks.text =
                    "English: $totalCorrect / $totalQuestions"
            }
        }
    }
}

