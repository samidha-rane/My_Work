package com.example.competitiveexampreparationapp

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class ProfileDBHelper(context: Context) : SQLiteOpenHelper(context, "ProfileDB.db", null, 1) {

    companion object {
        private const val TABLE_PROFILE = "profiles"
        private const val COL_USERNAME = "username"
        private const val COL_SUBJECT_PREF = "subjectPreference"
        private const val COL_OVERALL_SCORE = "overallScore"
    }

    override fun onCreate(db: SQLiteDatabase) {
        val createTable = """
            CREATE TABLE $TABLE_PROFILE (
                $COL_USERNAME TEXT PRIMARY KEY,
                $COL_SUBJECT_PREF TEXT,
                $COL_OVERALL_SCORE REAL
            )
        """.trimIndent()
        db.execSQL(createTable)
        db.execSQL("CREATE INDEX idx_username ON $TABLE_PROFILE($COL_USERNAME)")  // for faster lookups
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_PROFILE")
        onCreate(db)
    }

    fun insertOrUpdateProfile(username: String, subjectPref: String, overallScore: Double) {
        writableDatabase.use { db ->
            val values = ContentValues().apply {
                put(COL_USERNAME, username)
                put(COL_SUBJECT_PREF, subjectPref)
                put(COL_OVERALL_SCORE, overallScore)
            }
            val updatedRows = db.update(TABLE_PROFILE, values, "$COL_USERNAME=?", arrayOf(username))
            if (updatedRows == 0) {
                db.insert(TABLE_PROFILE, null, values)
            }
        }
    }

    fun getProfile(username: String): Map<String, Any>? {
        readableDatabase.use { db ->
            val cursor = db.rawQuery(
                "SELECT $COL_USERNAME, $COL_SUBJECT_PREF, $COL_OVERALL_SCORE FROM $TABLE_PROFILE WHERE $COL_USERNAME=?",
                arrayOf(username)
            )
            cursor.use {
                if (it.moveToFirst()) {
                    return mapOf(
                        "username" to it.getString(0),
                        "subjectPreference" to it.getString(1),
                        "overallScore" to it.getDouble(2)
                    )
                }
            }
        }
        return null
    }
}
