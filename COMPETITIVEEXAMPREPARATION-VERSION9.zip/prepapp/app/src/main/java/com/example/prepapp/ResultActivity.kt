package com.example.competitiveexampreparationapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.competitiveexampreparationapp.R

class ResultActivity : AppCompatActivity() {

    private lateinit var reportDB: ReportDBHelper
    private lateinit var userDB: UserDBHelper
    private lateinit var userId: String
    private lateinit var subject: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_result)

        reportDB = ReportDBHelper(this)
        userDB = UserDBHelper(this)

        // Use getLastUsername as current logged-in user
        userId = userDB.getLastUsername() ?: run {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            return
        }

        subject = intent.getStringExtra("subject") ?: "Quantitative Aptitude"

        val latestAttempts = reportDB.getLatestAttemptForUser(userId, subject)

        val totalQuestions = latestAttempts.size
        val correctAnswers = latestAttempts.count { it.userAnswer == it.correctIndex }

        findViewById<TextView>(R.id.tvScore).text = "Score: $correctAnswers / $totalQuestions"
        findViewById<TextView>(R.id.tvPercent).text =
            "Accuracy: ${if (totalQuestions > 0) (correctAnswers * 100 / totalQuestions) else 0}%"

        findViewById<Button>(R.id.btnViewReport).setOnClickListener {
            val intent = Intent(this, DetailedReportActivity::class.java).apply {
                putExtra("userId", userId)
                putExtra("subject", subject)
            }
            startActivity(intent)
        }

        findViewById<Button>(R.id.btnHome).setOnClickListener {
            startActivity(Intent(this, HomePageActivity::class.java))
            finish()
        }
    }

}
