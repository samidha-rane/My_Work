package com.example.competitiveexampreparationapp

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth

class SignupActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var dbHelper: UserDBHelper

    private lateinit var etEmail: EditText
    private lateinit var etPassword: EditText
    private lateinit var btnSignup: Button
    private lateinit var tvLogin: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_signup)

        // ✅ Firebase init
        FirebaseApp.initializeApp(this)
        auth = FirebaseAuth.getInstance()

        // ✅ SQLite init
        dbHelper = UserDBHelper(this)

        etEmail = findViewById(R.id.etEmail)
        etPassword = findViewById(R.id.etPassword)
        btnSignup = findViewById(R.id.btnSignup)
        tvLogin = findViewById(R.id.tvLogin)

        btnSignup.setOnClickListener {
            val email = etEmail.text.toString().trim()
            val password = etPassword.text.toString().trim()

            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Fill all fields", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (password.length < 6) {
                Toast.makeText(this, "Password must be at least 6 characters", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // ✅ Create Firebase user
            auth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        // ✅ Save to SQLite for local usage
                        val firstname = email.substringBefore("@")
                        val lastname = "NA"

                        if (!dbHelper.isUserExists(email)) {
                            dbHelper.insertUser(firstname, lastname)
                        }

                        Toast.makeText(this, "Signup Successful!", Toast.LENGTH_SHORT).show()

                        // 🔹 Option A: Go to Login
                        // startActivity(Intent(this, LoginActivity::class.java))

                        // 🔹 Option B: Auto-login to HomePage
                        startActivity(Intent(this, HomePageActivity::class.java))
                        finish()
                    } else {
                        val message = when (task.exception?.message) {
                            "The email address is already in use by another account." -> "Email already registered"
                            "The email address is badly formatted." -> "Invalid Email"
                            "The given password is invalid. [ Password should be at least 6 characters ]" -> "Weak Password"
                            else -> task.exception?.message ?: "Signup Failed"
                        }
                        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
                    }
                }
        }

        tvLogin.setOnClickListener {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }
    }
}
