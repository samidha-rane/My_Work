package com.example.competitiveexampreparationapp

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.competitiveexampreparationapp.R

class Totalscores : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_totalscores)

        val dbHelper = ReportDBHelper(this)

        // Get latest userId dynamically
        val userId = dbHelper.getLatestUserId()

        val totalScoreTextView: TextView = findViewById(R.id.totalScoreTextView)

        if (userId == null) {
            totalScoreTextView.text = "No data found"
            return
        }

        val subjects = listOf("Quantitative Aptitude", "Reasoning", "English")

        var totalCorrect = 0
        var totalQuestions = 0

        for (subject in subjects) {
            val attempts = dbHelper.getAttemptsForUser(userId, subject)
            totalCorrect += attempts.count { it.userAnswer == it.correctIndex }
            totalQuestions += attempts.size
        }

        totalScoreTextView.text = "Total Score: $totalCorrect / $totalQuestions"
    }
}
