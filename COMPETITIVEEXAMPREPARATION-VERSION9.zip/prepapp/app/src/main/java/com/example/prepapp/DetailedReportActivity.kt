package com.example.competitiveexampreparationapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.competitiveexampreparationapp.R

class DetailedReportActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detailed_report)
        val backButton=findViewById<Button>(R.id.btnBack)
        val container = findViewById<LinearLayout>(R.id.llReportContainer)
        val userId = intent.getStringExtra("userId") ?: "USER123"
        val subject = intent.getStringExtra("subject") ?: "Quantitative Aptitude"

        val db = ReportDBHelper(this)
        val attempts = db.getLatestAttemptForUser(userId, subject)


        attempts.forEachIndexed { index, q ->
            val tv = TextView(this).apply {
                text = buildString {
                    append("${index + 1}. ${q.questionText}\n")
                    append("Your Answer: ")
                    if (q.userAnswer >= 0) append(q.options[q.userAnswer]) else append("Not Answered")
                    append("\nCorrect Answer: ${q.options[q.correctIndex]}\n")
                }
                textSize = 16f
                setPadding(8, 12, 8, 12)
            }
            container.addView(tv)
        }
        backButton.setOnClickListener {
            val intent = Intent(this, ResultActivity::class.java)
            startActivity(intent)
        }
    }
}
