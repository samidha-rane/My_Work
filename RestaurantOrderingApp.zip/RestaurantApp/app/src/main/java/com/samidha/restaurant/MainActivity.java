package com.samidha.restaurant;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.util.*;

public class MainActivity extends AppCompatActivity {

    GridView gridView;
    Spinner spinnerCategory;
    Button btnViewCart;
    TextView tvWelcome;

    List<com.samidha.restaurant.MenuItem> allItems = new ArrayList<>();
    List<com.samidha.restaurant.MenuItem> filteredItems = new ArrayList<>();
    MenuGridAdapter adapter;

    SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences("UserSession", MODE_PRIVATE);

        gridView        = findViewById(R.id.gridView);
        spinnerCategory = findViewById(R.id.spinnerCategory);
        btnViewCart     = findViewById(R.id.btnViewCart);
        tvWelcome       = findViewById(R.id.tvWelcome);

        String name = prefs.getString("name", "Guest");
        tvWelcome.setText("Hello, " + name + "! 👋");

        loadMenuItems();
        setupSpinner();

        adapter = new MenuGridAdapter(this, filteredItems);
        gridView.setAdapter(adapter);

        btnViewCart.setOnClickListener(v ->
                startActivity(new Intent(this, CartActivity.class)));
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateCartButton();
    }

    void updateCartButton() {
        int count = CartManager.getInstance().getItemCount();
        btnViewCart.setText(count > 0 ? "View Cart (" + count + ")" : "View Cart");
    }

    void loadMenuItems() {
        allItems.add(new com.samidha.restaurant.MenuItem("Masala Dosa", "Crispy dosa with spiced potato filling", 80, "Breakfast"));
        allItems.add(new com.samidha.restaurant.MenuItem("Poha", "Light flattened rice with veggies", 50, "Breakfast"));
        allItems.add(new com.samidha.restaurant.MenuItem("Idli Sambar", "Steamed idlis with hot sambar", 60, "Breakfast"));
        allItems.add(new com.samidha.restaurant.MenuItem("Vada Pav", "Mumbai-style spicy vada in a pav", 30, "Snacks"));
        allItems.add(new com.samidha.restaurant.MenuItem("Samosa", "Crispy fried pastry with potato filling", 25, "Snacks"));
        allItems.add(new com.samidha.restaurant.MenuItem("Pav Bhaji", "Spiced vegetable mash with buttered pav", 100, "Snacks"));
        allItems.add(new com.samidha.restaurant.MenuItem("Dal Rice", "Comforting dal with steamed rice", 120, "Meals"));
        allItems.add(new com.samidha.restaurant.MenuItem("Thali", "Full meal with roti, dal, sabzi & rice", 180, "Meals"));
        allItems.add(new com.samidha.restaurant.MenuItem("Paneer Butter Masala", "Rich paneer curry with butter gravy", 160, "Meals"));
        allItems.add(new com.samidha.restaurant.MenuItem("Mango Lassi", "Chilled mango yoghurt drink", 60, "Drinks"));
        allItems.add(new com.samidha.restaurant.MenuItem("Masala Chai", "Spiced Indian tea", 20, "Drinks"));
        allItems.add(new com.samidha.restaurant.MenuItem("Gulab Jamun", "Soft milk-solid balls in sugar syrup", 50, "Desserts"));
        allItems.add(new com.samidha.restaurant.MenuItem("Kheer", "Creamy rice pudding with cardamom", 60, "Desserts"));

        filteredItems.addAll(allItems);
    }

    void setupSpinner() {
        List<String> categories = new ArrayList<>(Arrays.asList("All", "Breakfast", "Snacks", "Meals", "Drinks", "Desserts"));
        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, categories);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCategory.setAdapter(spinnerAdapter);

        spinnerCategory.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, android.view.View view, int pos, long id) {
                String selected = categories.get(pos);
                filteredItems.clear();
                if (selected.equals("All")) {
                    filteredItems.addAll(allItems);
                } else {
                    for (com.samidha.restaurant.MenuItem item : allItems) {
                        if (item.getCategory().equals(selected)) filteredItems.add(item);
                    }
                }
                adapter.notifyDataSetChanged();
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_logout) {
            prefs.edit().putBoolean("isLoggedIn", false).apply();
            CartManager.getInstance().clearCart();
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
