package com.samidha.restaurant;

import android.content.Context;
import android.view.*;
import android.widget.*;
import java.util.List;

public class MenuGridAdapter extends BaseAdapter {

    Context context;
    List<MenuItem> items;
    LayoutInflater inflater;

    public MenuGridAdapter(Context context, List<MenuItem> items) {
        this.context  = context;
        this.items    = items;
        this.inflater = LayoutInflater.from(context);
    }

    @Override public int getCount() { return items.size(); }
    @Override public Object getItem(int pos) { return items.get(pos); }
    @Override public long getItemId(int pos) { return pos; }

    @Override
    public View getView(int pos, View convertView, ViewGroup parent) {
        if (convertView == null)
            convertView = inflater.inflate(R.layout.item_menu, parent, false);

        MenuItem item = items.get(pos);

        TextView tvName        = convertView.findViewById(R.id.tvItemName);
        TextView tvDescription = convertView.findViewById(R.id.tvItemDescription);
        TextView tvPrice       = convertView.findViewById(R.id.tvItemPrice);
        TextView tvCategory    = convertView.findViewById(R.id.tvItemCategory);
        Button btnAdd          = convertView.findViewById(R.id.btnAddToCart);

        tvName.setText(item.getName());
        tvDescription.setText(item.getDescription());
        tvPrice.setText("₹" + (int) item.getPrice());
        tvCategory.setText(item.getCategory());

        btnAdd.setOnClickListener(v -> {
            CartManager.getInstance().addItem(item);
            Toast.makeText(context, item.getName() + " added to cart!", Toast.LENGTH_SHORT).show();
            if (context instanceof MainActivity) {
                ((MainActivity) context).updateCartButton();
            }
        });

        return convertView;
    }
}
