package com.samidha.restaurant;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.util.List;

public class CartActivity extends AppCompatActivity {

    ListView listViewCart;
    TextView tvTotal, tvEmpty;
    Button btnPlaceOrder;
    CartAdapter cartAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);

        listViewCart  = findViewById(R.id.listViewCart);
        tvTotal       = findViewById(R.id.tvTotal);
        tvEmpty       = findViewById(R.id.tvEmpty);
        btnPlaceOrder = findViewById(R.id.btnPlaceOrder);

        refreshCart();

        btnPlaceOrder.setOnClickListener(v -> {
            if (CartManager.getInstance().getCartItems().isEmpty()) {
                Toast.makeText(this, "Your cart is empty!", Toast.LENGTH_SHORT).show();
                return;
            }
            CartManager.getInstance().clearCart();
            startActivity(new Intent(this, OrderSuccessActivity.class));
            finish();
        });
    }

    void refreshCart() {
        List<MenuItem> cartItems = CartManager.getInstance().getCartItems();

        if (cartItems.isEmpty()) {
            tvEmpty.setVisibility(View.VISIBLE);
            listViewCart.setVisibility(View.GONE);
            btnPlaceOrder.setEnabled(false);
        } else {
            tvEmpty.setVisibility(View.GONE);
            listViewCart.setVisibility(View.VISIBLE);
            btnPlaceOrder.setEnabled(true);
        }

        cartAdapter = new CartAdapter(this, cartItems, this::refreshCart);
        listViewCart.setAdapter(cartAdapter);
        tvTotal.setText("Total: ₹" + String.format("%.0f", CartManager.getInstance().getTotal()));
    }
}
