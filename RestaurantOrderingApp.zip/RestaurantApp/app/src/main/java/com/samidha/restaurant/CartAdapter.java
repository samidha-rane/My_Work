package com.samidha.restaurant;

import android.content.Context;
import android.view.*;
import android.widget.*;
import java.util.List;

public class CartAdapter extends BaseAdapter {

    Context context;
    List<MenuItem> items;
    LayoutInflater inflater;
    Runnable onCartChanged;

    public CartAdapter(Context context, List<MenuItem> items, Runnable onCartChanged) {
        this.context       = context;
        this.items         = items;
        this.inflater      = LayoutInflater.from(context);
        this.onCartChanged = onCartChanged;
    }

    @Override public int getCount() { return items.size(); }
    @Override public Object getItem(int pos) { return items.get(pos); }
    @Override public long getItemId(int pos) { return pos; }

    @Override
    public View getView(int pos, View convertView, ViewGroup parent) {
        if (convertView == null)
            convertView = inflater.inflate(R.layout.item_cart, parent, false);

        MenuItem item = items.get(pos);

        TextView tvName     = convertView.findViewById(R.id.tvCartName);
        TextView tvPrice    = convertView.findViewById(R.id.tvCartPrice);
        TextView tvQuantity = convertView.findViewById(R.id.tvQuantity);
        Button btnPlus      = convertView.findViewById(R.id.btnPlus);
        Button btnMinus     = convertView.findViewById(R.id.btnMinus);
        Button btnRemove    = convertView.findViewById(R.id.btnRemove);

        tvName.setText(item.getName());
        tvPrice.setText("₹" + String.format("%.0f", item.getPrice() * item.getQuantity()));
        tvQuantity.setText(String.valueOf(item.getQuantity()));

        btnPlus.setOnClickListener(v -> {
            CartManager.getInstance().addItem(item);
            onCartChanged.run();
        });

        btnMinus.setOnClickListener(v -> {
            CartManager.getInstance().decreaseItem(item);
            onCartChanged.run();
        });

        btnRemove.setOnClickListener(v -> {
            CartManager.getInstance().removeItem(item);
            onCartChanged.run();
        });

        return convertView;
    }
}
