package com.samidha.restaurant;

import java.util.ArrayList;
import java.util.List;

public class CartManager {
    private static CartManager instance;
    private List<MenuItem> cartItems = new ArrayList<>();

    private CartManager() {}

    public static CartManager getInstance() {
        if (instance == null) instance = new CartManager();
        return instance;
    }

    public void addItem(MenuItem item) {
        for (MenuItem m : cartItems) {
            if (m.getName().equals(item.getName())) {
                m.setQuantity(m.getQuantity() + 1);
                return;
            }
        }
        item.setQuantity(1);
        cartItems.add(item);
    }

    public void removeItem(MenuItem item) {
        cartItems.removeIf(m -> m.getName().equals(item.getName()));
    }

    public void decreaseItem(MenuItem item) {
        for (MenuItem m : cartItems) {
            if (m.getName().equals(item.getName())) {
                if (m.getQuantity() > 1) m.setQuantity(m.getQuantity() - 1);
                else cartItems.remove(m);
                return;
            }
        }
    }

    public List<MenuItem> getCartItems() { return cartItems; }

    public double getTotal() {
        double total = 0;
        for (MenuItem m : cartItems) total += m.getPrice() * m.getQuantity();
        return total;
    }

    public int getItemCount() {
        int count = 0;
        for (MenuItem m : cartItems) count += m.getQuantity();
        return count;
    }

    public void clearCart() { cartItems.clear(); }
}
