# 🍽️ FoodieHub — Restaurant Ordering Android App

A fully functional Android food ordering app built with **Java**, **XML**, and **SharedPreferences**.

---

## 📱 Features

- **Splash Screen** — auto-redirects based on login state
- **Register / Login** — user authentication stored with SharedPreferences
- **Menu Screen** — items displayed in a 2-column GridView
- **Category Filter** — Spinner to filter by Breakfast, Snacks, Meals, Drinks, Desserts
- **Cart** — add, increase, decrease, or remove items; live total calculation
- **Place Order** — order success screen with navigation back to menu
- **Logout** — clears session and returns to login

---

## 🛠️ Tech Stack

| Layer | Technology |
|-------|-----------|
| Language | Java |
| UI | XML Layouts |
| Session Management | SharedPreferences |
| UI Components | GridView, Spinner, ListView, Toast, Snackbar, Intents |
| Architecture | Activity-based with Singleton CartManager |

---

## 📂 Project Structure

```
app/src/main/
├── java/com/samidha/restaurant/
│   ├── SplashActivity.java
│   ├── LoginActivity.java
│   ├── RegisterActivity.java
│   ├── MainActivity.java
│   ├── CartActivity.java
│   ├── OrderSuccessActivity.java
│   ├── MenuGridAdapter.java
│   ├── CartAdapter.java
│   ├── CartManager.java
│   └── MenuItem.java
├── res/
│   ├── layout/          # All XML layouts
│   ├── drawable/        # Custom backgrounds
│   ├── menu/            # Overflow menu
│   └── values/          # Colors, strings, themes
└── AndroidManifest.xml
```

---

## 🚀 How to Run

1. Clone this repo
2. Open in **Android Studio**
3. Let Gradle sync
4. Run on emulator or physical device (min SDK 21 / Android 5.0)

---

## 👩‍💻 Developer

**Samidha Rane** — Android & Web Developer  
📧 samidharane05@gmail.com  
🔗 [github.com/samidha-rane](https://github.com/samidha-rane/My_Work)
