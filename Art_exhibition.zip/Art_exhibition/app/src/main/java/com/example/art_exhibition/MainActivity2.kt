package com.example.art_exhibition


import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.art_exhibition.R

class MainActivity2 : AppCompatActivity() {

    private lateinit var listAdapter: ArrayAdapter<String>
    private val exhibits = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val isAuthorized = intent.getBooleanExtra("isAuthorized", false)
        if (!isAuthorized) {
            Toast.makeText(this, "Unauthorized access! Please log in.", Toast.LENGTH_LONG).show()
            startActivity(Intent(this, MainActivity2::class.java))
            finish()
            return
        }

        setContentView(R.layout.activity_main2)

        val titleInput = findViewById<EditText>(R.id.editExhibitTitle)
        val descInput = findViewById<EditText>(R.id.editExhibitDesc)
        val addButton = findViewById<Button>(R.id.btnAddExhibit)
        val exhibitList = findViewById<ListView>(R.id.listExhibits)

        listAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, exhibits)
        exhibitList.adapter = listAdapter

        addButton.setOnClickListener {
            val title = titleInput.text.toString().trim()
            val desc = descInput.text.toString().trim()

            if (title.isEmpty() || desc.isEmpty()) {
                Toast.makeText(this, "Please fill in both fields", Toast.LENGTH_SHORT).show()
            } else {
                val exhibitEntry = "$title\n$desc"
                exhibits.add(exhibitEntry)
                listAdapter.notifyDataSetChanged()
                titleInput.text.clear()
                descInput.text.clear()
                Toast.makeText(this, "Exhibit added", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
